# Sunset Scale

A circular rating-scale that can be used to assess ratings of pictures or objects, action-initiation/non-decision time, rating-time and mouse-data during the rating.

Install with `pip install git+git://github.com/julianquandt/sunset_scale` or if that does not work `python -m pip install git+git://github.com/julianquandt/sunset_scale`
